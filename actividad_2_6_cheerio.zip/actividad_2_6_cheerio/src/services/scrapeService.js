const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

const scrapeLocalHtml = () => {

  const filePath = path.join(__dirname, '../data/sample.html');

  const html = fs.readFileSync(filePath, 'utf-8');

  const $ = cheerio.load(html);

  const products = [];

  $('.product').each((index, element) => {

    const name = $(element).find('.name').text().trim();
    const price = $(element).find('.price').text().trim();
    const stock = $(element).find('.stock').text().trim();

    products.push({
      name,
      price,
      stock
    });

  });

  return products;
};

module.exports = {
  scrapeLocalHtml
};
module.exports = {
  scrapeLocalHtml
};