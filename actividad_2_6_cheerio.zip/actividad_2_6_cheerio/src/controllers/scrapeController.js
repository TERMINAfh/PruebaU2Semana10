const scrapeService = require('../services/scrapeService');

const getScrapedData = (req, res) => {

  try {

    const data = scrapeService.scrapeLocalHtml();

    res.status(200).json({
      success: true,
      total: data.length,
      data
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

module.exports = {
  getScrapedData
};